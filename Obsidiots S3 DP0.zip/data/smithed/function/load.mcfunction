tellraw @a[tag=team] {text:"RELOADED!",bold:true,color:"green"}

# Gamerules

gamerule fire_spread_radius_around_player 0

gamerule command_block_output false

# scoreboards
scoreboard objectives add smithed.has_brush dummy

scoreboard objectives add timer dummy