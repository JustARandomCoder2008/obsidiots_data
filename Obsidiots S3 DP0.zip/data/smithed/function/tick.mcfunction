execute as @e[type=minecraft:interaction,tag=discord_link] at @s if data entity @s interaction run execute as @p run function smithed:discord
execute as @e[type=minecraft:interaction,tag=modrinth_link] at @s if data entity @s interaction run execute as @p run function smithed:modrinth


execute if entity @e[tag=placing_padestal,type=armor_stand] as @e[tag=placing_padestal,type=armor_stand] run function smithed:place_padestal

execute at @e[tag=padestal,type=armor_stand] run function smithed:pedestal

execute as @e[tag=padestal,type=armor_stand] at @s unless block ~ ~ ~ quartz_block run function smithed:kill_pedestal
execute as @e[tag=padestal,type=armor_stand] at @s unless block ~ ~1 ~ glass run function smithed:kill_pedestal
execute as @e[tag=padestal,type=armor_stand] at @s unless block ~ ~2 ~ pale_oak_trapdoor run function smithed:kill_pedestal
execute as @e[tag=padestal,type=armor_stand] at @s anchored feet rotated as @s unless block ^ ^ ^1 pale_oak_wall_sign run function smithed:kill_pedestal
execute as @e[tag=padestal,type=armor_stand] at @s unless entity @e[type=item_frame,distance=..1] run function smithed:kill_pedestal


# scoreboard
scoreboard players add ClearItems timer 1

execute if score ClearItems timer matches 11400 run tellraw @a {text:"Killing all items in 30 seconds!",bold:true,color:red}
execute if score ClearItems timer matches 11800 run tellraw @a {text:"Killing all items in 10 seconds!",bold:true,color:yellow}
execute if score ClearItems timer matches 12000.. run function smithed:clearitems