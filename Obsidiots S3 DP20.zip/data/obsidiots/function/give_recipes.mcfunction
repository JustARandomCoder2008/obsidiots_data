schedule function obsidiots:give_recipes 10s

execute as @a run recipe give @s *
