give @s chainmail_helmet[custom_name="Emerald Helmet",equippable={slot:"head",asset_id:"obsidiots:emerald_armor",swappable:true}]
give @s chainmail_chestplate[custom_name="Emerald Chestplate",equippable={slot:"chest",asset_id:"obsidiots:emerald_armor",swappable:true}]
give @s chainmail_leggings[custom_name="Emerald Leggings",equippable={slot:"legs",asset_id:"obsidiots:emerald_armor",swappable:true}]
give @s chainmail_boots[custom_name="Emerald Boots",equippable={slot:"feet",asset_id:"obsidiots:emerald_armor",swappable:true}]