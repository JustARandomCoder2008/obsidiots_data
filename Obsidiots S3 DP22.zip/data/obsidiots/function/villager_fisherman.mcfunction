schedule function obsidiots:villager_fisherman 200t

# Musician Villager
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:fisherman",level:1}}] unless entity @s[tag=level1] if data entity @s Offers.Recipes run function obsidiots:set_trades/1
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:fisherman",level:2}}] unless entity @s[tag=level2] run function obsidiots:set_trades/2
    # No level3
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:fisherman",level:4}}] unless entity @s[tag=level4] run function obsidiots:set_trades/4
execute as @e[type=villager,nbt={VillagerData:{profession:"minecraft:fisherman",level:5}}] unless entity @s[tag=level5] run function obsidiots:set_trades/5