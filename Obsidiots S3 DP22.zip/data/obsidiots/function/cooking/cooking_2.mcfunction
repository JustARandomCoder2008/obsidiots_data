tag @s add cooking2
tag @s remove cooking1
tag @s add cooking

execute as @s if block ~ ~ ~ water_cauldron[level=3] if block ~ ~-1 ~ campfire[lit=true] run setblock ~ ~ ~ water_cauldron[level=2]
execute as @s if block ~ ~ ~ water_cauldron[level=2] if block ~ ~-1 ~ campfire[lit=true] run data modify entity @s Item.components."minecraft:custom_model_data" set value {floats:[1]}
