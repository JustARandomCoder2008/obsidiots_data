tag @s remove cooking3
tag @s remove cooking

execute as @s if block ~ ~ ~ water_cauldron[level=1] if block ~ ~-1 ~ campfire[lit=true] run setblock ~ ~ ~ cauldron
execute as @s if block ~ ~ ~ cauldron if block ~ ~-1 ~ campfire[lit=true] run data modify entity @s Item.id set value "dried_kelp"
execute as @s if block ~ ~ ~ cauldron if block ~ ~-1 ~ campfire[lit=true] run data modify entity @s Item.components set value {"custom_model_data":{floats:[7]},"item_name":"Boiled Egg",food:{nutrition:3,saturation:2,can_always_eat:true}}