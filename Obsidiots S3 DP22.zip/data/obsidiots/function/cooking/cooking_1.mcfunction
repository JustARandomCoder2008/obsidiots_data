tag @s add cooking1

tag @s add cooking