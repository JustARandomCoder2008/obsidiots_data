tag @s remove water
data modify entity @s Item.id set value "minecraft:evoker_spawn_egg"
data modify entity @s Item.components set value {"!entity_data":{}}