schedule function obsidiots:cooking/washing/check 5t

# Wheat
execute as @e[type=item,tag=!water,nbt={Item:{id:"minecraft:pillager_spawn_egg"}}] at @s if block ~ ~ ~ water run tag @s add water
execute as @e[type=item,tag=!water,nbt={Item:{id:"minecraft:pillager_spawn_egg"}}] at @s if block ~ ~ ~ #obsidiots:washing[waterlogged=true] run tag @s add water


# Finish
execute as @e[tag=water] run function obsidiots:cooking/washing/wheat_dough

# particle
execute at @e[tag=water] run particle minecraft:fishing ~ ~ ~ .1 .1 .1 .1 2
execute at @e[tag=water] run particle minecraft:splash ~ ~ ~ .1 .1 .1 .2 3