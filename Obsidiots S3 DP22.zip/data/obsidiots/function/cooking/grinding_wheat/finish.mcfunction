tag @s remove grinding
data modify entity @s Item.id set value "minecraft:pillager_spawn_egg"
data modify entity @s Item.components set value {"!entity_data":{}}