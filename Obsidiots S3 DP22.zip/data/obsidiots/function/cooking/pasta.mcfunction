tag @s remove cooking3
tag @s remove cooking

execute as @s if block ~ ~ ~ water_cauldron[level=1] if block ~ ~-1 ~ campfire[lit=true] run setblock ~ ~ ~ cauldron
execute as @s if block ~ ~ ~ cauldron if block ~ ~-1 ~ campfire[lit=true] run data modify entity @s Item.id set value "magma_cube_spawn_egg"
execute as @s if block ~ ~ ~ cauldron if block ~ ~-1 ~ campfire[lit=true] run data modify entity @s Item.components set value {"!entity_data":{}}