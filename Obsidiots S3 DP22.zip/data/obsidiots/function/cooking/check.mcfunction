schedule function obsidiots:cooking/check 5t

# rice
execute as @e[type=item,nbt={Item:{id:"minecraft:shulker_spawn_egg"}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=3] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_1
execute as @e[type=item,nbt={Item:{id:"minecraft:shulker_spawn_egg",components:{"minecraft:custom_model_data":{floats:[1f]}}}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=2] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_2
execute as @e[type=item,nbt={Item:{id:"minecraft:shulker_spawn_egg",components:{"minecraft:custom_model_data":{floats:[2f]}}}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=1] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_3

# pasta
execute as @e[type=item,nbt={Item:{id:"minecraft:piglin_spawn_egg"}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=3] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_1
execute as @e[type=item,nbt={Item:{id:"minecraft:piglin_spawn_egg",components:{"minecraft:custom_model_data":{floats:[1f]}}}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=2] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_2
execute as @e[type=item,nbt={Item:{id:"minecraft:piglin_spawn_egg",components:{"minecraft:custom_model_data":{floats:[2f]}}}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=1] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_3

# Egg
execute as @e[type=item,nbt={Item:{id:"minecraft:egg"}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=3] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_1
execute as @e[type=item,nbt={Item:{id:"minecraft:egg",components:{"minecraft:custom_model_data":{floats:[1f]}}}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=2] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_2
execute as @e[type=item,nbt={Item:{id:"minecraft:egg",components:{"minecraft:custom_model_data":{floats:[2f]}}}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=1] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_3

execute as @e[type=item,nbt={Item:{id:"minecraft:brown_egg"}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=3] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_1
execute as @e[type=item,nbt={Item:{id:"minecraft:brown_egg",components:{"minecraft:custom_model_data":{floats:[1f]}}}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=2] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_2
execute as @e[type=item,nbt={Item:{id:"minecraft:brown_egg",components:{"minecraft:custom_model_data":{floats:[2f]}}}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=1] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_3

execute as @e[type=item,nbt={Item:{id:"minecraft:blue_egg"}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=3] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_1
execute as @e[type=item,nbt={Item:{id:"minecraft:blue_egg",components:{"minecraft:custom_model_data":{floats:[1f]}}}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=2] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_2
execute as @e[type=item,nbt={Item:{id:"minecraft:blue_egg",components:{"minecraft:custom_model_data":{floats:[2f]}}}},tag=!cooking] at @s if block ~ ~ ~ water_cauldron[level=1] if block ~ ~-1 ~ campfire[lit=true] run function obsidiots:cooking/cooking_3


# Timer
execute as @e[type=item,tag=cooking] run scoreboard players add @s timer 1
execute as @e[tag=!cooking,type=item] unless entity @s[tag=grinding] run scoreboard players set @s timer 0

# Continue cooking
execute as @e[type=item,tag=cooking1] if score @s timer matches 12 at @s run function obsidiots:cooking/cooking_2
execute as @e[type=item,tag=cooking2] if score @s timer matches 24 at @s run function obsidiots:cooking/cooking_3

# !! FINISH COOKING!!!
execute as @e[type=item,tag=cooking3,nbt={Item:{id:"minecraft:shulker_spawn_egg"}}] if score @s timer matches 36 at @s run function obsidiots:cooking/rice
execute as @e[type=item,tag=cooking3,nbt={Item:{id:"minecraft:piglin_spawn_egg"}}] if score @s timer matches 36 at @s run function obsidiots:cooking/pasta
execute as @e[type=item,tag=cooking3,nbt={Item:{id:"minecraft:egg"}}] if score @s timer matches 36 at @s run function obsidiots:cooking/egg


# particles
execute as @e[tag=cooking] at @s if block ~ ~ ~ water_cauldron run particle bubble ~ ~.5 ~ .2 .2 .2 1 10 force