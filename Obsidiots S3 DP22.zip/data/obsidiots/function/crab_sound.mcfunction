schedule function obsidiots:crab_sound 10t

data modify entity @e[type=pig,limit=1,nbt={variant:"obsidiots:crab"}] Silent set value 1b
data modify entity @e[type=pig,limit=1,nbt={variant:"obsidiots:red_crab"}] Silent set value 1b