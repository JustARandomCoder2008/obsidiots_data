data modify entity @s Offers.Recipes[6] set value {buy:{id:"emerald",count:8},buyB:{id:"diamond",count:2},sell:{id:"jukebox",count:1},"maxUses":12,xp:2}
tag @s add level4