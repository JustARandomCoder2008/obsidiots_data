data modify entity @s Offers.Recipes[0] set value {buy:{id:"emerald",count:1},sell:{id:"disc_fragment_5",count:4},maxUses:12,xp:2}

tag @s add level1