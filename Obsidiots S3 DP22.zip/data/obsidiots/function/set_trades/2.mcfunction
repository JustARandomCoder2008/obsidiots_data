data modify entity @s Offers.Recipes[3] set value {buy:{id:"goat_horn",count:1},sell:{id:"emerald",count:2},"maxUses":12,xp:2}
tag @s add level2