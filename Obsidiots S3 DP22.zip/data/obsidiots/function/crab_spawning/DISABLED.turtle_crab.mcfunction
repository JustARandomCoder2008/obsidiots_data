schedule function obsidiots:crab_spawning/turtle_crab 10t

execute as @e[type=minecraft:turtle,tag=!obsidiots.crab_checked] store result score @s crab_roll run random roll 1..2

execute as @e[type=minecraft:turtle,tag=!obsidiots.crab_checked] if score @s crab_roll matches 1 at @s run summon minecraft:pig ~ ~ ~ {variant:"obsidiots:crab"}
execute as @e[type=minecraft:turtle,tag=!obsidiots.crab_checked] if score @s crab_roll matches 2 at @s run summon minecraft:pig ~ ~ ~ {variant:"obsidiots:red_crab"}

tag @e[type=minecraft:turtle,tag=!obsidiots.crab_checked] add obsidiots.crab_checked