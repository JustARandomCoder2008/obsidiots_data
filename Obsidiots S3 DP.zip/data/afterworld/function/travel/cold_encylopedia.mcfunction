effect give @s blindness 2 1 true
effect give @s slow_falling 1 0 true
execute in afterworld:encyclopedia run tp @s 0 2 0