effect give @s blindness 2 1 true
effect give @s slow_falling 1 0 true
execute in afterworld:cold run tp @s 0 64 0