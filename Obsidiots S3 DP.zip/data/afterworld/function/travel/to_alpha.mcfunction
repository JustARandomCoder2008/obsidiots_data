execute store result score @s afterworld.sleeping.RND run random value 0..100
#execute as @a if score @s afterworld.sleeping.RND matches 1 run function afterworld:travel/overworld_alpha
scoreboard players reset @s afterworld.sleeping.RND
tag @s add slept