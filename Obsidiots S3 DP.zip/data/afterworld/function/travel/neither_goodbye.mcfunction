effect give @s blindness 2 1 true
effect give @s slow_falling 1 0 true
execute in afterworld:goodbye run tp @s 0 400 0
execute in afterworld:goodbye if entity @s at @s positioned over motion_blocking_no_leaves run tp @s ~ ~ ~