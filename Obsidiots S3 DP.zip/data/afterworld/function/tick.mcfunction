
execute as @a[nbt={Dimension:"afterworld:alpha"}] at @s if entity @s[y=0,dy=-70] run function afterworld:travel/alpha_cold
execute as @e[type=armor_stand,tag=afterworld.rift] at @s in afterworld:cold if entity @s run execute if entity @a[distance=..0.6] as @p run function afterworld:travel/cold_encylopedia
execute as @a[nbt={Dimension:"afterworld:encyclopedia"}] at @s if entity @s[y=64,dy=64] run function afterworld:travel/encyclopedia_neither

execute as @e[type=armor_stand,tag=afterworld.rift] at @s in afterworld:neither if entity @s run execute if entity @a[distance=..0.6] as @p run function afterworld:travel/neither_goodbye


execute as @a[nbt={Dimension:"minecraft:overworld",SleepTimer:1s},tag=!slept,tag=afterworld.enabled] run function afterworld:travel/to_alpha

execute store result score afterworld.now afterworld.clock run time query day
execute if score afterworld.now afterworld.clock matches 1 run tag @a remove slept


execute as @a[tag=!afterworld.initiate] run function afterworld:initiate
execute as @a[scores={afterworld.enabled=2..},tag=afterworld.enabled] run function afterworld:trigger/toggle_2
execute as @a[scores={afterworld.enabled=1},tag=!afterworld.enabled] run function afterworld:trigger/toggle_1

#execute as @a[nbt={Dimension:"afterworld:neither"}] run effect give @s night_vision 15 0 true