
execute as @a[nbt={Dimension:"afterworld:alpha"}] at @s if entity @s[y=0,dy=-70] run function afterworld:travel/alpha_cold
execute as @e[type=armor_stand] in afterworld:cold at @s if entity @s[tag=afterworld.rift] run execute as @a[distance=..0.4] run function afterworld:travel/cold_encylopedia

execute as @a[nbt={Dimension:"minecraft:overworld",SleepTimer:1s},tag=!slept] unless score @s afterworld.enabled matches 1 run function afterworld:travel/to_alpha

execute store result score afterworld.now afterworld.clock run time query day
execute if score afterworld.now afterworld.clock matches 1 run tag @a remove slept


execute as @a[tag=!afterworld.initiate] run function afterworld:initiate