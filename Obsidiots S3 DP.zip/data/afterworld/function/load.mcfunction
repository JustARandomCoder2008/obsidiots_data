function afterworld:alpha_make_holes

scoreboard objectives add afterworld.enabled trigger
scoreboard players enable @a afterworld.enabled
scoreboard objectives add afterworld.sleeping.RND dummy
scoreboard objectives add afterworld.clock dummy