scoreboard players enable @s afterworld.enabled

tag @s add afterworld.initiate