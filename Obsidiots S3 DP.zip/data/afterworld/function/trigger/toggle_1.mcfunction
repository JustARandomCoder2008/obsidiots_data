tag @s add afterworld.enabled
scoreboard players enable @s afterworld.enabled
tellraw @s [{text:"Afterworld Travel is now:",bold:true},{text:" [ENABLED]",color:green}]