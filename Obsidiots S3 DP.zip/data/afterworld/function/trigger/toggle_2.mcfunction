scoreboard players set @s afterworld.enabled 0
tag @s remove afterworld.enabled
scoreboard players enable @s afterworld.enabled

tellraw @s [{text:"Afterworld Travel is now:",bold:true},{text:" [DISABLED]",color:red}]