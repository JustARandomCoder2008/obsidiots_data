schedule function afterworld:alpha_make_holes 2t

execute as @e[type=marker,tag=alpha_hole] at @s run fill ~ ~ ~ ~ 0 ~ air
execute as @e[type=marker,tag=alpha_hole] at @s run kill @s