schedule function obsidiots:set_decorative 5t

execute as @e[type=item_frame,nbt={Invisible:1b},tag=!invis] unless data entity @s Item run data modify entity @s Invisible set value 0b
execute as @e[type=armor_stand,nbt={Invisible:1b},tag=!invis] unless data entity @s equipment run data modify entity @s Invisible set value 0b

execute as @e[nbt={Item:{id:"minecraft:sheep_spawn_egg"}}] run data modify entity @s Invisible set value 1b
execute as @e[nbt={equipment:{head:{id:"minecraft:sheep_spawn_egg"}}}] run data modify entity @s Invisible set value 1b