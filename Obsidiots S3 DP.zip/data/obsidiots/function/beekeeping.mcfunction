schedule function obsidiots:beekeeping 2t

execute as @e[type=bee] at @s if entity @a[distance=..8,nbt={equipment:{head:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[1f]}}},chest:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[2f]}}},"legs":{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[3f]}}},feet:{"id":"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[4f]}}}}}] run data modify entity @s anger_end_time set value 0
