execute if entity @e[type=item_frame,limit=1,sort=nearest,nbt={Invisible:0b}] run data modify entity @e[type=item_frame,limit=1,sort=nearest] Invisible set value 1b
scoreboard players set @s invisible_item_frame 0
scoreboard players enable @s invisible_item_frame