scoreboard players enable @s invisible_item_frame
tag @s add IVIT