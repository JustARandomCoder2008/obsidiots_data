item replace entity @p weapon.mainhand with ravager_spawn_egg[entity_data={id:"marker",Tags:["Lamp.Used"]}]
execute unless score @s Lamp.Uses matches 3.. run tp sillylucy_ ~ ~ ~
execute unless score @s Lamp.Uses matches 3.. run scoreboard players add @s Lamp.Uses 1
kill @e[type=marker]