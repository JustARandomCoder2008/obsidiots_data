item replace entity @r player.crafting.0 with ravager_spawn_egg[entity_data={id:"marker",Tags:[Lamp.Used]},use_cooldown={seconds:3},lore=[{text:"Right click to teleport Lucy to you, So you can make a wish."}]]
execute unless score @s Lamp.Uses matches 3.. run tp sillylucy_ ~ ~ ~
execute unless score @s Lamp.Uses matches 3.. run scoreboard players add @s Lamp.Uses 1
kill @e[type=marker]