schedule function obsidiots:lamp/detect 3t

execute at @e[type=marker,tag=Lamp.Used] as @p run function obsidiots:lamp/use_lamp