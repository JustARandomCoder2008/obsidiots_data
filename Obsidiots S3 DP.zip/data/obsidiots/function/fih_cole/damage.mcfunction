damage @s 2 drown
scoreboard players set @s oxygen_timer 0