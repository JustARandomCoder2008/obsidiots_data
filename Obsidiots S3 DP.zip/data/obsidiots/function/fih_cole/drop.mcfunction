loot spawn ~ ~ ~ loot obsidiots:fishy
scoreboard players set @s deaths 0