tag @s add fih

bossbar set obsidiots:nicole_o2 players @s
attribute @s minecraft:max_health base set 14
attribute @s minecraft:submerged_mining_speed base set 1
attribute @s water_movement_efficiency base set 1