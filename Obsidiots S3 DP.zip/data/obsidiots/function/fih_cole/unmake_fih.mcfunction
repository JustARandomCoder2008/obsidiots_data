tag @s remove fih

bossbar set obsidiots:nicole_o2 players
attribute @s minecraft:max_health base reset
attribute @s minecraft:submerged_mining_speed base reset
attribute @s water_movement_efficiency base reset