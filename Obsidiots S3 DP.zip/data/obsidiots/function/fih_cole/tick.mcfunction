execute as @s at @s if score @s deaths matches 1.. run function obsidiots:fih_cole/drop

effect give @s water_breathing 15 0 true


# Drowning on land
execute unless entity @s[nbt={equipment:{head:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[13f]}}}}}] run function obsidiots:fih_cole/no_helmet

execute if entity @s[nbt={equipment:{head:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[13f]}}}}}] run scoreboard players remove @s oxygen_timer 1

execute if block ~ ~1 ~ water run scoreboard players remove @s oxygen_timer 1
execute if block ~ ~0 ~ water run scoreboard players remove @s oxygen_timer 1

execute if score @s oxygen_timer matches ..-81 run scoreboard players set @s oxygen_timer -80
execute if entity @e[tag=aria,distance=..2] run scoreboard players set @s oxygen_timer -80

execute if score @s oxygen_timer matches -80 run bossbar set obsidiots:nicole_o2 value 8
execute if score @s oxygen_timer matches -70 run bossbar set obsidiots:nicole_o2 value 7
execute if score @s oxygen_timer matches -60 run bossbar set obsidiots:nicole_o2 value 6
execute if score @s oxygen_timer matches -50 run bossbar set obsidiots:nicole_o2 value 5
execute if score @s oxygen_timer matches -40 run bossbar set obsidiots:nicole_o2 value 4
execute if score @s oxygen_timer matches -30 run bossbar set obsidiots:nicole_o2 value 3
execute if score @s oxygen_timer matches -20 run bossbar set obsidiots:nicole_o2 value 2
execute if score @s oxygen_timer matches -10 run bossbar set obsidiots:nicole_o2 value 1
execute if score @s oxygen_timer matches 0 run bossbar set obsidiots:nicole_o2 value 0

# Water helmet
execute if entity @s[nbt={equipment:{head:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[13f]}}}}}] run scoreboard players add @s water_helmet_timer 1

execute as @s[scores={water_helmet_timer=1200..}] run function obsidiots:fih_cole/helmet_damage

execute if score @s water_helmet_timer matches 1200.. run scoreboard players add @s water_helmet_damage 1

execute if score @s water_helmet_damage matches 1 run item modify entity @s armor.head {function:"set_components",components:{damage:1}}
execute if score @s water_helmet_damage matches 2 run item modify entity @s armor.head {function:"set_components",components:{damage:2}}
execute if score @s water_helmet_damage matches 3 run item modify entity @s armor.head {function:"set_components",components:{damage:3}}
execute if score @s water_helmet_damage matches 4 run item modify entity @s armor.head {function:"set_components",components:{damage:4}}
execute if score @s water_helmet_damage matches 5 run item modify entity @s armor.head {function:"set_components",components:{damage:5}}
execute if score @s water_helmet_damage matches 6 run item modify entity @s armor.head {function:"set_components",components:{damage:6}}
execute if score @s water_helmet_damage matches 7 run item modify entity @s armor.head {function:"set_components",components:{damage:7}}
execute if score @s water_helmet_damage matches 8 run item modify entity @s armor.head {function:"set_components",components:{damage:8}}
execute if score @s water_helmet_damage matches 9 run item modify entity @s armor.head {function:"set_components",components:{damage:9}}
execute if score @s water_helmet_damage matches 10 run item modify entity @s armor.head {function:"set_components",components:{damage:10}}
execute if score @s water_helmet_damage matches 11 run item modify entity @s armor.head {function:"set_components",components:{damage:11}}
execute if score @s water_helmet_damage matches 12 run item modify entity @s armor.head {function:"set_components",components:{damage:12}}
execute if score @s water_helmet_damage matches 13 run item modify entity @s armor.head {function:"set_components",components:{damage:13}}
execute if score @s water_helmet_damage matches 14 run item modify entity @s armor.head {function:"set_components",components:{damage:14}}
execute if score @s water_helmet_damage matches 15 run item modify entity @s armor.head {function:"set_components",components:{damage:15}}
execute if score @s water_helmet_damage matches 16 run item modify entity @s armor.head {function:"set_components",components:{damage:16}}
execute if score @s water_helmet_damage matches 17 run item modify entity @s armor.head {function:"set_components",components:{damage:17}}
execute if score @s water_helmet_damage matches 18 run item modify entity @s armor.head {function:"set_components",components:{damage:18}}
execute if score @s water_helmet_damage matches 19 run item modify entity @s armor.head {function:"set_components",components:{damage:19}}
execute if score @s water_helmet_damage matches 20 run item modify entity @s armor.head {function:"set_components",components:{damage:20}}
execute if score @s water_helmet_damage matches 21 run item modify entity @s armor.head {function:"set_components",components:{damage:21}}
execute if score @s water_helmet_damage matches 22 run item modify entity @s armor.head {function:"set_components",components:{damage:22}}
execute if score @s water_helmet_damage matches 23 run item modify entity @s armor.head {function:"set_components",components:{damage:23}}
execute if score @s water_helmet_damage matches 24 run item modify entity @s armor.head {function:"set_components",components:{damage:24}}
execute if score @s water_helmet_damage matches 25 run item modify entity @s armor.head {function:"set_components",components:{damage:25}}
execute if score @s water_helmet_damage matches 26 run item modify entity @s armor.head {function:"set_components",components:{damage:26}}
execute if score @s water_helmet_damage matches 27 run item modify entity @s armor.head {function:"set_components",components:{damage:27}}
execute if score @s water_helmet_damage matches 28 run item modify entity @s armor.head {function:"set_components",components:{damage:28}}
execute if score @s water_helmet_damage matches 29 run item modify entity @s armor.head {function:"set_components",components:{damage:29}}
execute if score @s water_helmet_damage matches 30 run item modify entity @s armor.head {function:"set_components",components:{damage:30}}
execute if score @s water_helmet_damage matches 31 run item modify entity @s armor.head {function:"set_components",components:{damage:31}}
execute if score @s water_helmet_damage matches 32 run item modify entity @s armor.head {function:"set_components",components:{damage:32}}
execute if score @s water_helmet_damage matches 32 run scoreboard players set @s water_helmet_damage 0

execute if score @s water_helmet_timer matches 1200.. run scoreboard players set @s water_helmet_timer 0