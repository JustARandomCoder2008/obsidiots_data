execute unless block ~ ~1 ~ water unless block ~ ~ ~ water run scoreboard players add @s oxygen_timer 1



execute if score @s oxygen_timer matches 20.. run function obsidiots:fih_cole/damage