scoreboard players set @a timber_mined_oak 0
scoreboard players set @a timber_mined_spruce 0
scoreboard players set @a timber_mined_birch 0
scoreboard players set @a timber_mined_jungle 0
scoreboard players set @a timber_mined_acacia 0
scoreboard players set @a timber_mined_dark_oak 0
scoreboard players set @a timber_mined_mangrove 0
scoreboard players set @a timber_mined_cherry 0
scoreboard players set @a timber_mined_pale_oak 0
scoreboard players set @a timber_mined_crimson 0
scoreboard players set @a timber_mined_warped 0

tellraw @p {text:"TIMBER FIRED"}

execute anchored eyes run summon minecraft:marker ^ ^ ^ {Tags:["obsidiots_timber"]}

data modify entity @e[type=minecraft:marker,tag=obsidiots_timber,limit=1,sort=nearest] Rotation set from entity @p Rotation
execute as @e[type=minecraft:marker,tag=obsidiots_timber,limit=1,sort=nearest] at @s run function obsidiots:enchantments/timber/search


