execute as @e[tag=obsidiots.echo_pending] if score @s echo_timer matches 1.. run scoreboard players remove @s echo_timer 1

execute as @e[tag=obsidiots.echo_pending] if score @s echo_timer matches ..1 run damage @s 2 minecraft:generic

execute as @e[tag=obsidiots.echo_pending] if score @s echo_timer matches ..1 run tag @s remove obsidiots.echo_pending