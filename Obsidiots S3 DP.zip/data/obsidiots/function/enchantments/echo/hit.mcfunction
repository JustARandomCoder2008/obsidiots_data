tag @s add obsidiots.echo_pending
scoreboard players set @s echo_timer 20