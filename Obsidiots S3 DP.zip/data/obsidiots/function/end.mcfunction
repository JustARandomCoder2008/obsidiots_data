schedule function obsidiots:end 5t
execute as @a if entity @s[nbt={Dimension:"minecraft:the_end"}] run attribute @s gravity base set 0.016
execute as @a unless entity @s[nbt={Dimension:"minecraft:the_end"}] run attribute @s gravity base set 0.08