attribute @s air_drag_modifier base set 2048
scoreboard players add @s builder.end.floating_timer 1