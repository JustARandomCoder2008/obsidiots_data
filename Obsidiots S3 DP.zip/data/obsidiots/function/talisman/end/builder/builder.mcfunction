execute as @s if block ~ ~-1 ~ air if score @s sneak_time matches 1.. unless score @s builder.end.floating_timer matches 40.. run function obsidiots:talisman/end/builder/float

execute as @s if score @s builder.end.floating_timer matches 40.. run attribute @s air_drag_modifier base reset
execute as @s if score @s builder.end.floating_timer matches 40..50 run scoreboard players add @s builder.end.floating_timer 1
execute as @s if score @s builder.end.floating_timer matches 50.. run scoreboard players reset @s builder.end.floating_timer

execute as @s unless score @s sneak_time matches -2147483648..2147483647 run attribute @s air_drag_modifier base reset
execute as @s unless score @s sneak_time matches -2147483648..2147483647 unless score @s builder.end.floating_timer matches 40.. run scoreboard players reset @s builder.end.floating_timer