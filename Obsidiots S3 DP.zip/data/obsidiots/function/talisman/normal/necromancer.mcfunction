# Undead Friend
tag @s add necromancer
team join necromancer @e[type=#undead,distance=..32]

