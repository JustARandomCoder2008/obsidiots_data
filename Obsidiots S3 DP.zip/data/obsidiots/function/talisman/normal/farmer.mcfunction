# Larger follow range
execute as @e[type=#followable_friendly_mobs,distance=..16] run attribute @s follow_range base set 16
execute as @e[type=#followable_friendly_mobs,distance=16..] run attribute @s follow_range base reset

# Sneak Harvest
execute if score @s sneak_time matches 1.. if block ~-1 ~.1 ~-1 minecraft:wheat[age=7] run loot spawn ~-1 ~.1 ~-1 loot obsidiots:blocks/wheat
execute if score @s sneak_time matches 1.. if block ~-1 ~.1 ~0 minecraft:wheat[age=7] run loot spawn ~-1 ~.1 ~0 loot obsidiots:blocks/wheat
execute if score @s sneak_time matches 1.. if block ~-1 ~.1 ~1 minecraft:wheat[age=7] run loot spawn ~-1 ~.1 ~1 loot obsidiots:blocks/wheat
execute if score @s sneak_time matches 1.. if block ~0 ~.1 ~-1 minecraft:wheat[age=7] run loot spawn ~0 ~.1 ~-1 loot obsidiots:blocks/wheat
execute if score @s sneak_time matches 1.. if block ~0 ~.1 ~0 minecraft:wheat[age=7] run loot spawn ~0 ~.1 ~0 loot obsidiots:blocks/wheat
execute if score @s sneak_time matches 1.. if block ~0 ~.1 ~1 minecraft:wheat[age=7] run loot spawn ~0 ~.1 ~1 loot obsidiots:blocks/wheat
execute if score @s sneak_time matches 1.. if block ~1 ~.1 ~-1 minecraft:wheat[age=7] run loot spawn ~1 ~.1 ~-1 loot obsidiots:blocks/wheat
execute if score @s sneak_time matches 1.. if block ~1 ~.1 ~0 minecraft:wheat[age=7] run loot spawn ~1 ~.1 ~0 loot obsidiots:blocks/wheat
execute if score @s sneak_time matches 1.. if block ~1 ~.1 ~1 minecraft:wheat[age=7] run loot spawn ~1 ~.1 ~1 loot obsidiots:blocks/wheat

execute if score @s sneak_time matches 1.. run fill ~-1 ~.1 ~-1 ~1 ~.1 ~1 wheat[age=0] replace wheat[age=7]