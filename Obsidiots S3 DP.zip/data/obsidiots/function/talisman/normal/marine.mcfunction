# Conduit effect

effect give @s conduit_power 10 0