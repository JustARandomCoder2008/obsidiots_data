schedule function obsidiots:talisman/tick 3t

# Item detector
execute as @a[nbt={equipment:{offhand:{id:"minecraft:wolf_spawn_egg",components:{"minecraft:custom_model_data":{floats:[4f]}}}}}] at @s run function obsidiots:talisman/normal/farmer
execute as @a[nbt={equipment:{offhand:{id:"minecraft:bat_spawn_egg",components:{"minecraft:custom_model_data":{floats:[6f]}}}}}] at @s if block ~ ~ ~ water run function obsidiots:talisman/normal/marine
execute as @a[nbt={equipment:{offhand:{id:"minecraft:horse_spawn_egg",components:{"minecraft:custom_model_data":{floats:[7f]}}}}}] at @s run function obsidiots:talisman/normal/necromancer

# Teams
team add necromancer
team add fighter

execute as @a[tag=necromancer] run team join necromancer
execute as @a[tag=!necromancer] run team leave @s

execute as @a unless items entity @s weapon.offhand horse_spawn_egg[custom_model_data={floats:[7]}] run tag @s remove necromancer

scoreboard players reset @a sneak_time