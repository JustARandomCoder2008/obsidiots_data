schedule function obsidiots:talisman/tick 5t

# Item detector
execute as @a[nbt={equipment:{offhand:{id:"minecraft:wolf_spawn_egg",components:{"minecraft:custom_model_data":{floats:[4f]}}}}}] at @s run function obsidiots:talisman/normal/farmer
execute as @a[nbt={equipment:{offhand:{id:"minecraft:bat_spawn_egg",components:{"minecraft:custom_model_data":{floats:[6f]}}}}}] at @s if block ~ ~ ~ water run function obsidiots:talisman/normal/marine
execute as @a[nbt={equipment:{offhand:{id:"minecraft:horse_spawn_egg",components:{"minecraft:custom_model_data":{floats:[7f]}}}}}] at @s run function obsidiots:talisman/normal/necromancer

execute as @a[nbt={equipment:{offhand:{id:"minecraft:frog_spawn_egg",components:{"minecraft:custom_model_data":{floats:[0f]}}}}}] at @s run function obsidiots:talisman/end/adventurer

execute as @a[nbt={equipment:{offhand:{id:"minecraft:frog_spawn_egg",components:{"minecraft:custom_model_data":{floats:[1f]}}}}}] at @s run function obsidiots:talisman/nether/miner

execute as @a[nbt={equipment:{offhand:{id:"minecraft:frog_spawn_egg",components:{"minecraft:custom_model_data":{floats:[2f]}}}}}] at @s run function obsidiots:talisman/end/builder/builder


# Teams
team add necromancer
team add fighter

execute as @a[tag=necromancer] run team join necromancer
execute as @a[tag=!necromancer] run team leave @s

execute as @a unless items entity @s weapon.offhand horse_spawn_egg[custom_model_data={floats:[7]}] run tag @s remove necromancer
execute as @a unless items entity @s weapon.offhand frog_spawn_egg[custom_model_data={floats:[1]}] run tag @s remove Miner_Nether

execute as @a unless items entity @s weapon.offhand frog_spawn_egg[custom_model_data={floats:[2]}] run scoreboard players reset @s builder.end.floating_timer
execute as @a unless items entity @s weapon.offhand frog_spawn_egg[custom_model_data={floats:[2]}] run attribute @s air_drag_modifier base reset



scoreboard players reset @a sneak_time