schedule function obsidiots:more_rain/main 10t

execute store result score rain random run random value 0..20
scoreboard players add rain timer 1

execute if score rain timer matches 900.. if score rain random matches ..1 run weather rain
execute if score rain timer matches 900.. run scoreboard players set rain timer 0