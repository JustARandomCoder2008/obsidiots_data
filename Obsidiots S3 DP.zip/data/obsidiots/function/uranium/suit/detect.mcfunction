schedule function obsidiots:uranium/suit/detect 5t

execute as @a unless items entity @s armor.head minecraft:flint[minecraft:custom_model_data={floats:[10.0]}] run function obsidiots:uranium/item
execute as @a unless items entity @s armor.chest minecraft:flint[minecraft:custom_model_data={floats:[11.0]}] run function obsidiots:uranium/item
execute as @a unless items entity @s armor.feet minecraft:flint[minecraft:custom_model_data={floats:[12.0]}] run function obsidiots:uranium/item