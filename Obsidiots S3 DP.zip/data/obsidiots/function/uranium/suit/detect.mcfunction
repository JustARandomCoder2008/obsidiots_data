schedule function obsidiots:uranium/suit/detect 5t

execute as @a unless entity @s[nbt={equipment:{feet:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[12f]}}},chest:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[11f]}}},head:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[10f]}}}}}] run function obsidiots:uranium/item