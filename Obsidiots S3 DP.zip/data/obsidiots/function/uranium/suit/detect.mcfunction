schedule function obsidiots:uranium/suit/detect 5t

tag @a remove radiation_suit
execute as @a[nbt={equipment:{head:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[10f]}}},chest:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[11f]}}},feet:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[12f]}}}}}] run tag @s add radiation_suit

execute as @a unless entity @s[tag=radiation_suit] run function obsidiots:uranium/item