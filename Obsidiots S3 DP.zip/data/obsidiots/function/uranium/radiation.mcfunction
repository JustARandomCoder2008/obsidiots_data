effect give @s nausea 5 1
effect give @s poison 5 1
effect give @s mining_fatigue 30 1