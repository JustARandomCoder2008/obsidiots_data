
execute as @a at @s if entity @e[type=item,nbt={Item:{id:"minecraft:allay_spawn_egg"}},distance=..8] run function obsidiots:uranium/radiation
execute as @a at @s if entity @e[type=item,nbt={Item:{id:"minecraft:mooshroom_spawn_egg"}},distance=..8] run function obsidiots:uranium/radiation

execute as @a if items entity @s container.* allay_spawn_egg run function obsidiots:uranium/radiation
execute as @a if items entity @s container.* mooshroom_spawn_egg run function obsidiots:uranium/radiation
execute as @a if items entity @s container.* lodestone run function obsidiots:uranium/radiation
execute as @a if items entity @s container.* gilded_blackstone run function obsidiots:uranium/radiation
execute as @a if items entity @s container.* sniffer_spawn_egg run function obsidiots:uranium/radiation
execute as @a if items entity @s container.* cookie[custom_model_data={floats:[7]}] run function obsidiots:uranium/radiation