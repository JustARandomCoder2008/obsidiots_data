place template obsidiots:nuke ~-24 ~-6 ~-24
place template obsidiots:nuke ~-24 ~-10 ~-24
kill @e[type=item,distance=..128]
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s unless entity @e[type=marker,tag=radiation,distance=..32] run summon marker ~ ~ ~ {Tags:["radiation"]}

execute as @a at @s if entity @e[type=armor_stand,tag=nuke,distance=..128] run playsound entity.generic.explode master @s ~ ~ ~ 2 0.2 1
execute as @a at @s if entity @e[type=armor_stand,tag=nuke,distance=..128] run playsound entity.generic.explode master @s ~ ~ ~ 2 0.2 1
execute as @a at @s if entity @e[type=armor_stand,tag=nuke,distance=..128] run playsound entity.generic.explode master @s ~ ~ ~ 2 0.2 1
execute as @a at @s if entity @e[type=armor_stand,tag=nuke,distance=..128] run playsound entity.generic.explode master @s ~ ~ ~ 2 0.2 1

fill ~-60 ~-30 ~-60 ~60 ~30 ~60 air replace #leaves
fill ~-50 ~-30 ~-50 ~50 ~30 ~50 air replace #logs
fill ~-60 ~-30 ~-60 ~60 ~30 ~60 air replace #obsidiots:foiliage
fill ~-45 ~-30 ~-45 ~45 ~30 ~45 short_dry_grass replace short_grass
fill ~-50 ~-30 ~-50 ~50 ~30 ~50 fire replace tall_grass
fill ~-50 ~-30 ~-50 ~50 ~30 ~50 fire replace fern
fill ~-60 ~-30 ~-60 ~60 ~30 ~60 dead_bush replace bush
fill ~-60 ~-30 ~-60 ~60 ~30 ~60 coarse_dirt replace #grass_blocks


execute as @e at @s if entity @e[type=armor_stand,tag=nuke,distance=..30] run damage @s 50 explosion
execute as @e at @s if entity @e[type=armor_stand,tag=nuke,distance=..60] run damage @s 20 explosion
execute as @e at @s if entity @e[type=armor_stand,tag=nuke,distance=..80] run damage @s 15 explosion
execute as @e at @s if entity @e[type=armor_stand,tag=nuke,distance=..60] run damage @s 10 explosion