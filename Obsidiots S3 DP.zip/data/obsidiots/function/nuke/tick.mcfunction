schedule function obsidiots:nuke/tick 5t

#timer
scoreboard players add @e[type=armor_stand,tag=nuke] nuke_timer 1

# Particles
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 120.. run particle minecraft:explosion ~ ~ ~ 10 2 10 0 60 force
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 120.. run particle minecraft:large_smoke ~ ~ ~ 10 2 10 0 80 force
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 120.. run particle minecraft:dust{color:16777215,scale:4} ~ ~45 ~ 10 6 10 1 300 force
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 120.. run particle minecraft:dust{color:16777215,scale:4} ~ ~50 ~ 5 6 5 0 150 force
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 120.. run particle minecraft:dust_color_transition{from_color:9723229,to_color:13217390,scale:1} ~ ~ ~ 0 50 0 1 30 force
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 120.. run particle minecraft:dust_color_transition{from_color:9723229,to_color:13217390,scale:4} ~ ~ ~ 2 25 2 5 450 force
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 120.. run particle minecraft:dust{color:16777215,scale:4} ~ ~25 ~ 4 0.5 4 3 15 force
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 120.. run particle minecraft:dust_color_transition{from_color:9723229,to_color:13217390,scale:4} ~ ~45 ~ 8 5 8 1 450 force


# Explosion
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 120 run function obsidiots:nuke/explosion
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 120.. run execute as @a[distance=..64] unless entity @s[nbt={equipment:{head:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[10]}}},chest:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[11]}}},feet:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[12]}}}}}] run function obsidiots:uranium/radiation
execute as @e[type=minecraft:armor_stand,tag=nuke] if score @s nuke_timer matches 128.. run kill @e[type=item,distance=..128]
execute as @e[type=minecraft:armor_stand,tag=nuke] if score @s nuke_timer matches 128.. run kill @s

# fallout
scoreboard players add @e[type=marker,tag=radiation] nuke_timer 1
execute as @e[type=marker,tag=radiation] at @s unless score @s nuke_timer matches 2400.. run execute as @a[distance=..100] unless entity @s[nbt={equipment:{feet:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[12f]}}},chest:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[11f]}}},head:{id:"minecraft:flint",components:{"minecraft:custom_model_data":{floats:[10f]}}}}}] run function obsidiots:uranium/radiation
execute as @e[type=marker,tag=radiation] at @s if score @s nuke_timer matches 2400.. run kill @s
execute as @e[type=marker,tag=radiation] at @s positioned over motion_blocking_no_leaves run particle dust_color_transition{from_color:8560744,to_color:12960401,scale:2} ~ ~ ~ 100 50 100 .5 500 force


# Timer Display
execute if entity @e[type=armor_stand,tag=nuke] as @e[type=armor_stand,tag=nuke] at @s if score @s nuke_timer matches ..2 run bossbar add obsidiots:nuke {text:"☢ DETONATION IN 00:30",color:"red",bold:true}
execute if entity @e[type=armor_stand,tag=nuke] as @e[type=armor_stand,tag=nuke] at @s if score @s nuke_timer matches ..2 run bossbar set obsidiots:nuke max 30
execute if entity @e[type=armor_stand,tag=nuke] as @e[type=armor_stand,tag=nuke] at @s if score @s nuke_timer matches ..2 run bossbar set obsidiots:nuke value 30
execute if entity @e[type=armor_stand,tag=nuke] as @e[type=armor_stand,tag=nuke] at @s if score @s nuke_timer matches ..2 run bossbar set obsidiots:nuke color green
execute if entity @e[type=armor_stand,tag=nuke] as @e[type=armor_stand,tag=nuke] at @s if score @s nuke_timer matches ..2 run bossbar set obsidiots:nuke style notched_20
execute if entity @e[type=armor_stand,tag=nuke] as @e[type=armor_stand,tag=nuke] at @s run bossbar set obsidiots:nuke players @a[distance=..128]

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 4 run bossbar set obsidiots:nuke value 29
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 4 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:29",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 8 run bossbar set obsidiots:nuke value 28
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 8 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:28",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 12 run bossbar set obsidiots:nuke value 27
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 12 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:27",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 16 run bossbar set obsidiots:nuke value 26
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 16 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:26",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 20 run bossbar set obsidiots:nuke value 25
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 20 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:25",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 24 run bossbar set obsidiots:nuke value 24
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 24 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:24",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 28 run bossbar set obsidiots:nuke value 23
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 28 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:23",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 32 run bossbar set obsidiots:nuke value 22
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 32 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:22",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 36 run bossbar set obsidiots:nuke value 21
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 36 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:21",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 40 run bossbar set obsidiots:nuke value 20
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 40 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:20",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 44 run bossbar set obsidiots:nuke value 19
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 44 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:19",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 48 run bossbar set obsidiots:nuke value 18
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 48 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:18",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 52 run bossbar set obsidiots:nuke value 17
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 52 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:17",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 56 run bossbar set obsidiots:nuke value 16
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 56 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:16",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 60 run bossbar set obsidiots:nuke value 15
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 60 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:15",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 64 run bossbar set obsidiots:nuke value 14
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 64 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:14",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 68 run bossbar set obsidiots:nuke value 13
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 68 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:13",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 72 run bossbar set obsidiots:nuke value 12
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 72 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:12",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 76 run bossbar set obsidiots:nuke value 11
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 76 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:11",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 80 run bossbar set obsidiots:nuke value 10
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 80 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:10",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 84 run bossbar set obsidiots:nuke value 9
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 84 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:09",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 88 run bossbar set obsidiots:nuke value 8
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 88 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:08",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 92 run bossbar set obsidiots:nuke value 7
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 92 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:07",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 96 run bossbar set obsidiots:nuke value 6
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 96 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:06",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 100 run bossbar set obsidiots:nuke value 5
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 100 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:05",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 104 run bossbar set obsidiots:nuke value 4
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 104 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:04",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 108 run bossbar set obsidiots:nuke value 3
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 108 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:03",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 112 run bossbar set obsidiots:nuke value 2
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 112 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:02",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 116 run bossbar set obsidiots:nuke value 1
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 116 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:01",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 120 run bossbar set obsidiots:nuke value 0
execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 120 run bossbar set obsidiots:nuke name {text:"☢ DETONATION IN 00:00",color:"red",bold:true}

execute as @e[type=minecraft:armor_stand,tag=nuke] at @s if score @s nuke_timer matches 120 run bossbar remove obsidiots:nuke
execute unless entity @e[type=armor_stand,tag=nuke] run bossbar remove obsidiots:nuke