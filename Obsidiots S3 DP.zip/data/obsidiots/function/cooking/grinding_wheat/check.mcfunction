schedule function obsidiots:cooking/grinding_wheat/check 5t

# wheat 
execute as @e[type=item,tag=!grinding,nbt={Item:{id:"minecraft:wheat"}}] at @s if block ~ ~-.5 ~ grindstone run tag @s add grinding
execute as @e[type=item,tag=grinding,nbt={Item:{id:"minecraft:wheat"}}] at @s unless block ~ ~-.5 ~ grindstone run tag @s remove grinding


# timer
execute as @e[tag=grinding,type=item] run scoreboard players add @s timer 1
execute as @e[tag=!grinding,type=item] run scoreboard players set @s timer 0

# Finish
execute as @e[tag=grinding] if score @s timer matches 20 run function obsidiots:cooking/grinding_wheat/finish

# particle
execute at @e[tag=grinding] run particle minecraft:dust_plume ~ ~ ~ .1 .1 .1 .1 2
execute at @e[tag=grinding] run particle minecraft:crit ~ ~ ~ .1 .1 .1 .2 3