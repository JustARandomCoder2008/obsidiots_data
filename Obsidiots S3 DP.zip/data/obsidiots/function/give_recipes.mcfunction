schedule function obsidiots:give_recipes 1s

execute as @a[tag=!obsidiots.recipe] run recipe give @s *
execute as @a[tag=!obsidiots.recipe] run tag @s add obsidiots.recipe