give @s chainmail_helmet[custom_name="Base Test Helmet",equippable={slot:"head",asset_id:"obsidiots:base_armor",swappable:true}]
give @s chainmail_chestplate[custom_name="Base Test Chestplate",equippable={slot:"chest",asset_id:"obsidiots:base_armor",swappable:true}]
give @s chainmail_leggings[custom_name="Base Test Leggings",equippable={slot:"legs",asset_id:"obsidiots:base_armor",swappable:true}]
give @s chainmail_boots[custom_name="Base Test Boots",equippable={slot:"feet",asset_id:"obsidiots:base_armor",swappable:true}]