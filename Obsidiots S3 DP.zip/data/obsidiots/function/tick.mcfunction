#enchantments
function obsidiots:enchantments/hasty/tick
function obsidiots:enchantments/timber/tick
function obsidiots:aria/tick

# triggers
execute as @a[scores={invisible_item_frame=1..}] at @s run function obsidiots:triggers/if_invisible
execute as @a[tag=!IVIT] run function obsidiots:triggers/initiate_item_frame

execute as @a[tag=!recipe] run recipe give @s *
execute as @a[tag=!recipe] run tag @s add recipe