execute as @e[type=cat,nbt={CustomName:"Flor"}] run data merge entity @s {variant: "obsidiots:flor"}
execute as @e[type=cat,nbt={CustomName:"flor"}] run data merge entity @s {variant: "obsidiots:flor"}

# hasty enchantment
execute as @a if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"obsidiots:hasty",levels:1}]] run effect give @s minecraft:haste 2 0
execute as @a if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"obsidiots:hasty",levels:2}]] run effect give @s minecraft:haste 2 1
execute as @a if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"obsidiots:hasty",levels:3}]] run effect give @s minecraft:haste 2 2
execute as @a if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"obsidiots:hasty",levels:4}]] run effect give @s minecraft:haste 2 3