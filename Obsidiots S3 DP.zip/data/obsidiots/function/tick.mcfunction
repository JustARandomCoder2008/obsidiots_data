#enchantments
function obsidiots:enchantments/hasty/tick
function obsidiots:enchantments/timber/tick
function obsidiots:aria/tick

