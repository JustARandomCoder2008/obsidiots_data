execute as @e[type=cat,nbt={CustomName:"Flor"}] run data merge entity @s {variant: "obsidiots:flor"}
execute as @e[type=cat,nbt={CustomName:"flor"}] run data merge entity @s {variant: "obsidiots:flor"}

#enchantments
function obsidiots:enchantments/hasty/tick
function obsidiots:enchantments/timber/tick