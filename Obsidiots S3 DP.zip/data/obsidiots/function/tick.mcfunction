#enchantments
function obsidiots:enchantments/hasty/tick
function obsidiots:enchantments/timber/tick
function obsidiots:enchantments/echo/tick
function obsidiots:aria/tick
execute as @a[tag=fih] at @s run function obsidiots:fih_cole/tick


# triggers
execute as @a[scores={invisible_item_frame=1..}] at @s run function obsidiots:triggers/if_invisible
execute as @a[tag=!IVIT] run function obsidiots:triggers/initiate_item_frame

execute as @a[tag=!recipe] run recipe give @s *
execute as @a[tag=!recipe] run tag @s add recipe

#execute as @a[scores={sneak_time=1..}] run scoreboard players reset @s sneak_time