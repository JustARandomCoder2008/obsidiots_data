execute if block ~ ~1 ~ #smithed:miners_light run setblock ~ ~1 ~ light
execute unless block ~ ~1 ~ #smithed:miners_light if block ~ ~ ~ #smithed:miners_light run setblock ~ ~ ~ light

execute if block ~ ~1.1 ~ light run summon marker ~ ~1.1 ~ {Tags:[miners_light]}
execute unless block ~ ~1 ~ light if block ~ ~ ~ light run summon marker ~ ~ ~ {Tags:["miners_light"]}