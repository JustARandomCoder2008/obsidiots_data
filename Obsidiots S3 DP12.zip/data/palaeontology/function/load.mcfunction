# scoreboards

scoreboard objectives add ammonite_broken dummy
scoreboard objectives add crinoid_broken dummy
scoreboard objectives add triolobite_broken dummy
scoreboard objectives add rock_broken dummy
scoreboard objectives add shell_broken dummy
scoreboard objectives add shark_tooth_broken dummy
scoreboard objectives add trace_broken dummy
scoreboard objectives add leaf_broken dummy
scoreboard objectives add graptolite_broken dummy
scoreboard objectives add insect_broken dummy
scoreboard objectives add boulder_broken dummy
scoreboard objectives add bonebound_boulder_broken dummy
scoreboard objectives add fossil_skull_boulder_broken dummy
scoreboard objectives add petrified_fern_boulder_broken dummy



scoreboard players set broken ammonite_broken 0


scoreboard players set broken rock_broken 0