execute as @e[type=minecraft:item_frame,tag=rock_frame] unless data entity @s Item.id run kill @s



execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[1.0f]}}}}] at @s run kill @e[type=item,distance=..1,limit=1,nbt={Item:{id:"minecraft:item_frame"}}]
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[2.0f]}}}}] at @s run kill @e[type=item,distance=..1,limit=1,nbt={Item:{id:"minecraft:item_frame"}}]
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[3.0f]}}}}] at @s run kill @e[type=item,distance=..1,limit=1,nbt={Item:{id:"minecraft:item_frame"}}]
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[4.0f]}}}}] at @s run kill @e[type=item,distance=..1,limit=1,nbt={Item:{id:"minecraft:item_frame"}}]
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[5.0f]}}}}] at @s run kill @e[type=item,distance=..1,limit=1,nbt={Item:{id:"minecraft:item_frame"}}]
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[6.0f]}}}}] at @s run kill @e[type=item,distance=..1,limit=1,nbt={Item:{id:"minecraft:item_frame"}}]
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[7.0f]}}}}] at @s run kill @e[type=item,distance=..1,limit=1,nbt={Item:{id:"minecraft:item_frame"}}]
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[8.0f]}}}}] at @s run kill @e[type=item,distance=..1,limit=1,nbt={Item:{id:"minecraft:item_frame"}}]
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[9.0f]}}}}] at @s run kill @e[type=item,distance=..1,limit=1,nbt={Item:{id:"minecraft:item_frame"}}]
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[10.0f]}}}}] at @s run kill @e[type=item,distance=..1,limit=1,nbt={Item:{id:"minecraft:item_frame"}}]
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[11.0f]}}}}] at @s run kill @e[type=item,distance=..1,limit=1,nbt={Item:{id:"minecraft:item_frame"}}]
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[12.0f]}}}}] at @s run kill @e[type=item,distance=..1,limit=1,nbt={Item:{id:"minecraft:item_frame"}}]
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[13.0f]}}}}] at @s run kill @e[type=item,distance=..1,limit=1,nbt={Item:{id:"minecraft:item_frame"}}]
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[14.0f]}}}}] at @s run kill @e[type=item,distance=..1,limit=1,nbt={Item:{id:"minecraft:item_frame"}}]


execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[1.0f]}}}}] at @s run scoreboard players add broken ammonite_broken 1
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[2.0f]}}}}] at @s run scoreboard players add broken crinoid_broken 1
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[3.0f]}}}}] at @s run scoreboard players add broken triolobite_broken 1
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[4.0f]}}}}] at @s run scoreboard players add broken rock_broken 1 
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[5.0f]}}}}] at @s run scoreboard players add broken shell_broken 1
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[6.0f]}}}}] at @s run scoreboard players add broken shark_tooth_broken 1
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[7.0f]}}}}] at @s run scoreboard players add broken trace_broken 1
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[8.0f]}}}}] at @s run scoreboard players add broken leaf_broken 1
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[9.0f]}}}}] at @s run scoreboard players add broken graptolite_broken 1
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[10.0f]}}}}] at @s run scoreboard players add broken insect_broken 1
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[11.0f]}}}}] at @s run scoreboard players add broken boulder_broken 1
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[12.0f]}}}}] at @s run scoreboard players add broken bonebound_boulder_broken 1
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[13.0f]}}}}] at @s run scoreboard players add broken fossil_skull_boulder_broken 1
execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[14.0f]}}}}] at @s run scoreboard players add broken petrified_fern_boulder_broken 1


execute if score broken ammonite_broken matches 2.. run execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[1.0f]}}}}] at @s run function palaeontology:rocks/replace_ammonite
execute if score broken crinoid_broken matches 2.. run execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[2.0f]}}}}] at @s run function palaeontology:rocks/replace_crinoid
execute if score broken triolobite_broken matches 2.. run execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[3.0f]}}}}] at @s run function palaeontology:rocks/replace_trilobite
execute if score broken rock_broken matches 2.. run execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[4.0f]}}}}] at @s run function palaeontology:rocks/replace_rock
execute if score broken shell_broken matches 2.. run execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[5.0f]}}}}] at @s run function palaeontology:rocks/replace_shell
execute if score broken shark_tooth_broken matches 2.. run execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[6.0f]}}}}] at @s run function palaeontology:rocks/replace_shark_tooth
execute if score broken trace_broken matches 2.. run execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[7.0f]}}}}] at @s run function palaeontology:rocks/replace_trace
execute if score broken leaf_broken matches 2.. run execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[8.0f]}}}}] at @s run function palaeontology:rocks/replace_leaf
execute if score broken graptolite_broken matches 2.. run execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[9.0f]}}}}] at @s run function palaeontology:rocks/replace_graptolite
execute if score broken insect_broken matches 2.. run execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[10.0f]}}}}] at @s run function palaeontology:rocks/replace_insect
execute if score broken boulder_broken matches 2.. run execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[11.0f]}}}}] at @s run function palaeontology:rocks/replace_boulder
execute if score broken bonebound_boulder_broken matches 2.. run execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[12.0f]}}}}] at @s run function palaeontology:rocks/replace_bone_boulder
execute if score broken fossil_skull_boulder_broken matches 2.. run execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[13.0f]}}}}] at @s run function palaeontology:rocks/replace_skull_boulder
execute if score broken petrified_fern_boulder_broken matches 2.. run execute as @e[type=item,nbt={Item:{id:"minecraft:stone",components:{"minecraft:custom_model_data":{floats:[14.0f]}}}}] at @s run function palaeontology:rocks/replace_petrified_fern_boulder