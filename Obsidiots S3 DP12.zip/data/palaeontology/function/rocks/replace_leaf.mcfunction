summon item ~ ~ ~ {Item:{id:"item_frame",components:{item_name:"Leaf Fossil",custom_model_data:{floats:[8]},entity_data:{id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[8b]}},count:1b}}}}}
kill @s
scoreboard players set broken leaf_broken 0