summon item ~ ~ ~ {Item:{id:"item_frame",components:{item_name:"Boulder",custom_model_data:{floats:[11]},entity_data:{id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[11b]}},count:1b}}}}}
kill @s
scoreboard players set broken boulder_broken 0