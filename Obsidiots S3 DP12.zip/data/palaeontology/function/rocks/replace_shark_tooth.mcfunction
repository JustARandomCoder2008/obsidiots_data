summon item ~ ~ ~ {Item:{id:"item_frame",components:{item_name:"Shark Tooth Fossil",custom_model_data:{floats:[6]},entity_data:{id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[6b]}},count:1b}}}}}
kill @s
scoreboard players set broken shark_tooth_broken 0