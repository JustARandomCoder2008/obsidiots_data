summon item ~ ~ ~ {Item:{id:"item_frame",components:{item_name:"Rock",custom_model_data:{floats:[4]},entity_data:{id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[4b]}},count:1b}}}}}
kill @s
scoreboard players set broken rock_broken 0