summon item ~ ~ ~ {Item:{id:"item_frame",components:{item_name:"Graptolite Fossil",custom_model_data:{floats:[9]},entity_data:{id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[9b]}},count:1b}}}}}
kill @s
scoreboard players set broken graptolite_broken 0