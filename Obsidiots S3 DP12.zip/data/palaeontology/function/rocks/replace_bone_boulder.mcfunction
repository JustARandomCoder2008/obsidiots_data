summon item ~ ~ ~ {Item:{id:"item_frame",components:{item_name:"Bonebound Boulder",custom_model_data:{floats:[12]},entity_data:{id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[12b]}},count:1b}}}}}
kill @s
scoreboard players set broken bonebound_boulder_broken 0