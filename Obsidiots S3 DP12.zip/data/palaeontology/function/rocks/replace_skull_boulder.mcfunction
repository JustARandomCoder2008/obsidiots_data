summon item ~ ~ ~ {Item:{id:"item_frame",components:{item_name:"Fossilized Skull Boulder",custom_model_data:{floats:[13]},entity_data:{id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[13b]}},count:1b}}}}}
kill @s
scoreboard players set broken fossil_skull_boulder_broken 0