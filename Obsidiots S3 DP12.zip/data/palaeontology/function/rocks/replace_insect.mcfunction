summon item ~ ~ ~ {Item:{id:"item_frame",components:{item_name:"Insect Fossil",custom_model_data:{floats:[10]},entity_data:{id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[10b]}},count:1b}}}}}
kill @s
scoreboard players set broken insect_broken 0