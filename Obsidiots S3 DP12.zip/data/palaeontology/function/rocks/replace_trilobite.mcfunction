summon item ~ ~ ~ {Item:{id:"item_frame",components:{item_name:"Trilobite Fossil",custom_model_data:{floats:[3]},entity_data:{id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[3b]}},count:1b}}}}}
kill @s
scoreboard players set broken triolobite_broken 0