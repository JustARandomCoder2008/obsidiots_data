summon item ~ ~ ~ {Item:{id:"item_frame",components:{item_name:"Petrified Fern Boulder",custom_model_data:{floats:[14]},entity_data:{id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[14b]}},count:1b}}}}}
kill @s
scoreboard players set broken petrified_fern_boulder_broken 0