summon item ~ ~ ~ {Item:{id:"item_frame",components:{item_name:"Shell Fossil",custom_model_data:{floats:[5]},entity_data:{id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[5b]}},count:1b}}}}}
kill @s
scoreboard players set broken shell_broken 0