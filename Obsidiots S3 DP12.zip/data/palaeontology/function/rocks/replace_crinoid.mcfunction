summon item ~ ~ ~ {Item:{id:"item_frame",components:{item_name:"Crinoid Fossil",custom_model_data:{floats:[2]},entity_data:{id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[2b]}},count:1b}}}}}
kill @s
scoreboard players set broken crinoid_broken 0