summon item ~ ~ ~ {Item:{id:"item_frame",components:{item_name:"Ammonite Fossil",custom_model_data:{floats:[1]},entity_data:{id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[1b]}},count:1b}}}}}
kill @s
scoreboard players set broken ammonite_broken 0