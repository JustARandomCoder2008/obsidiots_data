summon item ~ ~ ~ {Item:{id:"item_frame",components:{item_name:"Trace Fossil",custom_model_data:{floats:[7]},entity_data:{id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[7b]}},count:1b}}}}}
kill @s
scoreboard players set broken trace_broken 0