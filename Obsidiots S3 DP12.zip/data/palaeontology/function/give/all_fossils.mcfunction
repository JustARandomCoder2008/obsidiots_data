give @s item_frame[item_name="Ammonite Fossil",custom_model_data={floats:[1]},entity_data={id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[1]}},count:1b}}]

give @s item_frame[item_name="Crinoid Fossil",custom_model_data={floats:[2]},entity_data={id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[2]}},count:1b}}]

give @s item_frame[item_name="Trilobite Fossil",custom_model_data={floats:[3]},entity_data={id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[3]}},count:1b}}]

give @s item_frame[item_name="Rock",custom_model_data={floats:[4]},entity_data={id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[4]}},count:1b}}]

give @s item_frame[item_name="Shell Fossil",custom_model_data={floats:[5]},entity_data={id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[5]}},count:1b}}]

give @s item_frame[item_name="Shark Tooth Fossil",custom_model_data={floats:[6]},entity_data={id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[6]}},count:1b}}]

give @s item_frame[item_name="Trace Fossil",custom_model_data={floats:[7]},entity_data={id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[7]}},count:1b}}]

give @s item_frame[item_name="Leaf Fossil",custom_model_data={floats:[8]},entity_data={id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[8]}},count:1b}}]

give @s item_frame[item_name="Graptolite Fossil",custom_model_data={floats:[9]},entity_data={id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[9]}},count:1b}}]

give @s item_frame[item_name="Insect Fossil",custom_model_data={floats:[10]},entity_data={id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[10]}},count:1b}}]

give @s item_frame[item_name="Boulder",custom_model_data={floats:[11]},entity_data={id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[11]}},count:1b}}]

give @s item_frame[item_name="Bonebound Boulder",custom_model_data={floats:[12]},entity_data={id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[12]}},count:1b}}]

give @s item_frame[item_name="Fossil Skull Boulder",custom_model_data={floats:[13]},entity_data={id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[13]}},count:1b}}]

give @s item_frame[item_name="Petrified Fern Boulder",custom_model_data={floats:[14]},entity_data={id:"item_frame",Invisible:1b,Tags:["rock_frame"],Item:{id:"stone",components:{custom_model_data:{floats:[14]}},count:1b}}]