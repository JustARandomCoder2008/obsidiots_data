give @s minecraft:suspicious_sand[minecraft:item_name="Coastal Fossil Rich Soil",minecraft:block_entity_data={id:"minecraft:brushable_block",LootTable:"palaeontology:sand"}]

give @s minecraft:suspicious_gravel[minecraft:item_name="Ancient Coastal Fossil Rich Soil",minecraft:block_entity_data={id:"minecraft:brushable_block",LootTable:"palaeontology:gravel"}]

give @s minecraft:suspicious_gravel[minecraft:item_name="Terrestrial Fossil Rich Soil",minecraft:block_entity_data={id:"minecraft:brushable_block",LootTable:"palaeontology:forest"}]