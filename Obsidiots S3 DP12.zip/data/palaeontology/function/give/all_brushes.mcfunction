give @s brush[max_damage=32,custom_model_data={floats:[1]},item_name={"translate": "item.palaeontology.brush.wood"}]
give @s brush
give @s brush[max_damage=151,custom_model_data={floats:[2]},item_name={"translate": "item.palaeontology.brush.iron"}]
give @s brush[max_damage=48,custom_model_data={floats:[3]},item_name={"translate": "item.palaeontology.brush.gold"}]
give @s brush[max_damage=751,custom_model_data={floats:[4]},item_name={"translate": "item.palaeontology.brush.diamond"}]
give @s brush[max_damage=1561,custom_model_data={floats:[5]},item_name={"translate": "item.palaeontology.brush.netherite"}]