kill @e[type=item]
tellraw @a {text:"Killed all items!",bold:true,color:green}

scoreboard players set ClearItems timer 0