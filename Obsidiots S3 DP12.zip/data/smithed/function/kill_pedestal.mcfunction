fill ~-1 ~ ~-1 ~1 ~2 ~1 air

summon item ~ ~ ~ {Tags:["new_item"],Item:{id:"minecraft:structure_void",count:1},Motion:[-.03,.3,.05]}

execute if data entity @e[type=item_frame,tag=padestal_display_frame,limit=1,sort=nearest,distance=..2.5] Item run data modify entity @e[type=item,tag=new_item,limit=1,sort=nearest,distance=..1] Item set from entity @e[type=item_frame,tag=padestal_display_frame,limit=1,sort=nearest,distance=..2.5] Item
execute unless data entity @e[type=item_frame,tag=padestal_display_frame,limit=1,sort=nearest,distance=..2.5] Item run data modify entity @e[type=item,tag=new_item,limit=1,sort=nearest,distance=..1] Item set value {"id":"minecraft:air"}
execute as @e[tag=new_item] at @s unless entity @e[type=item_frame,distance=..1,tag=padestal_display_frame] run kill @s

kill @e[type=item_display,tag=padestal_display,limit=1,sort=nearest,distance=..1.5]
kill @e[type=item_frame,tag=padestal_display_frame,limit=1,sort=nearest,distance=..1.5]
kill @e[type=item,nbt={Item:{id:"minecraft:pale_oak_sign"}},distance=..2,limit=1,sort=nearest]
kill @e[type=item,nbt={Item:{id:"minecraft:item_frame"}},distance=..2,limit=1,sort=nearest]
kill @e[type=item,nbt={Item:{id:"minecraft:quartz_block"}},distance=..2,limit=1,sort=nearest]
kill @e[type=item,nbt={Item:{id:"minecraft:glass"}},distance=..2,limit=1,sort=nearest]
kill @e[type=item,nbt={Item:{id:"minecraft:pale_oak_trapdoor"}},distance=..3,limit=1,sort=nearest]




kill @s

summon item ~ ~ ~ {Item:{id:pig_spawn_egg,components:{entity_data:{id:"minecraft:armor_stand",Tags:["placing_padestal"]},item_name:"Item Padestal",custom_model_data:{floats:[123401]}}},Motion:[0.01,.3,-.05]}
