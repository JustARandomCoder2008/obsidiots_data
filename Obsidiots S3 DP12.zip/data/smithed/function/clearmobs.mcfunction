kill @s
kill @e[type=item]

scoreboard players set ClearMobs timer 0