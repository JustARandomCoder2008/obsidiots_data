give @p stick
give @p iron_ingot
give @p feather