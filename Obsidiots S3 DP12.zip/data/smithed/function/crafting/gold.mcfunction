give @p stick
give @p gold_ingot
give @p feather