give @p stick
give @p copper_ingot
give @p feather