give @p stick
give @p copper_ingot
give @p feather
give @p netherite_upgrade_smithing_template
give @p netherite_ingot