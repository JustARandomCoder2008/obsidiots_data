give @p stick
give @p string
give @p feather