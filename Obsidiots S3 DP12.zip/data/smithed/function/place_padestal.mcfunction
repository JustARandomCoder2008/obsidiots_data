execute at @s run tp @s ~ ~ ~ facing entity @p eyes
# Place structure

execute if entity @s[y_rotation=45..134] at @s run place template smithed:padestal/padestal ~-1 ~-1 ~ none
    
execute if entity @s[y_rotation=135..180] at @s run place template smithed:padestal/padestal ~ ~-1 ~-1 clockwise_90
execute if entity @s[y_rotation=-180..-134] at @s run place template smithed:padestal/padestal ~ ~-1 ~-1 clockwise_90

execute if entity @s[y_rotation=-45..44] at @s run place template smithed:padestal/padestal ~ ~-1 ~1 counterclockwise_90

execute if entity @s[y_rotation=-135..-44] at @s run place template smithed:padestal/padestal ~1 ~-1 ~ 180

# final touchess

execute at @s run tag @e[type=item_display,limit=1,distance=..1.5,sort=nearest] add padestal_display
execute at @s run tag @e[type=item_frame,limit=1,distance=..1,sort=nearest] add padestal_display_frame

data modify entity @s Invisible set value 1b

tag @s add padestal
tag @s remove placing_padestal

