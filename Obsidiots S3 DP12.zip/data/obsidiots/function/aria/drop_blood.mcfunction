loot spawn ~ ~ ~ loot obsidiots:drop_blood
scoreboard players set @s deaths 0