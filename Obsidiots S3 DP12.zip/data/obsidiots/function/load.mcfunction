scoreboard objectives add timber_mined_oak minecraft.mined:minecraft.oak_log
scoreboard objectives add timber_mined_spruce minecraft.mined:minecraft.spruce_log
scoreboard objectives add timber_mined_birch minecraft.mined:minecraft.birch_log
scoreboard objectives add timber_mined_jungle minecraft.mined:minecraft.jungle_log
scoreboard objectives add timber_mined_acacia minecraft.mined:minecraft.acacia_log
scoreboard objectives add timber_mined_dark_oak minecraft.mined:minecraft.dark_oak_log
scoreboard objectives add timber_mined_mangrove minecraft.mined:minecraft.mangrove_log
scoreboard objectives add timber_mined_cherry minecraft.mined:minecraft.cherry_log
scoreboard objectives add timber_mined_pale_oak minecraft.mined:minecraft.pale_oak_log
scoreboard objectives add timber_mined_crimson minecraft.mined:minecraft.crimson_stem
scoreboard objectives add timber_mined_warped minecraft.mined:minecraft.warped_stem


scoreboard players set @a timber_mined_oak 0
scoreboard players set @a timber_mined_spruce 0
scoreboard players set @a timber_mined_birch 0
scoreboard players set @a timber_mined_jungle 0
scoreboard players set @a timber_mined_acacia 0
scoreboard players set @a timber_mined_dark_oak 0
scoreboard players set @a timber_mined_mangrove 0
scoreboard players set @a timber_mined_cherry 0
scoreboard players set @a timber_mined_pale_oak 0
scoreboard players set @a timber_mined_crimson 0
scoreboard players set @a timber_mined_warped 0

scoreboard objectives add deaths deathCount

kill @e[type=marker]

function obsidiots:infinite_trading