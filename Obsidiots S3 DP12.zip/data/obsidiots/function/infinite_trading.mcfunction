schedule function obsidiots:infinite_trading 2s replace


execute as @e[type=villager,nbt=!{VillagerData:{profession:"minecraft:none"}},nbt=!{VillagerData:{profession:"minecraft:nitwit"}}] if data entity @s Offers.Recipes[0] run data modify entity @s Offers.Recipes[] merge value {demand:-1,maxUses:2147483647}
execute as @e[type=wandering_trader] if data entity @s Offers.Recipes[0] run data modify entity @s Offers.Recipes[] merge value {demand:-1,maxUses:2147483647}