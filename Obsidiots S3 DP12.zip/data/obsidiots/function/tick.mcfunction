execute as @e[type=cat,nbt={CustomName:"Flor"}] run data merge entity @s {variant: "obsidiots:flor"}
execute as @e[type=cat,nbt={CustomName:"flor"}] run data merge entity @s {variant: "obsidiots:flor"}

#enchantments
function obsidiots:enchantments/hasty/tick
function obsidiots:enchantments/timber/tick
function obsidiots:aria/tick

# Limitless Villager Trades
execute as @e[type=minecraft:villager,tag=limitless_trades] run data modify entity @s Offers.Recipes[0].uses set value 0
execute as @e[type=minecraft:villager,tag=limitless_trades] run data modify entity @s Offers.Recipes[1].uses set value 0
execute as @e[type=minecraft:villager,tag=limitless_trades] run data modify entity @s Offers.Recipes[2].uses set value 0
execute as @e[type=minecraft:villager,tag=limitless_trades] run data modify entity @s Offers.Recipes[3].uses set value 0
execute as @e[type=minecraft:villager,tag=limitless_trades] run data modify entity @s Offers.Recipes[4].uses set value 0
execute as @e[type=minecraft:villager,tag=limitless_trades] run data modify entity @s Offers.Recipes[5].uses set value 0
execute as @e[type=minecraft:villager,tag=limitless_trades] run data modify entity @s Offers.Recipes[6].uses set value 0
execute as @e[type=minecraft:villager,tag=limitless_trades] run data modify entity @s Offers.Recipes[7].uses set value 0
execute as @e[type=minecraft:villager,tag=limitless_trades] run data modify entity @s Offers.Recipes[8].uses set value 0
execute as @e[type=minecraft:villager,tag=limitless_trades] run data modify entity @s Offers.Recipes[9].uses set value 0