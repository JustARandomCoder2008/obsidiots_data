execute if block ~ ~1 ~ #logs run setblock ~ ~1 ~ air destroy
tp @s ~ ~1 ~
execute at @s as @s unless block ~ ~1 ~ #logs run kill @s
execute as @s at @s if block ~ ~1 ~ #logs run function obsidiots:enchantments/timber/timber