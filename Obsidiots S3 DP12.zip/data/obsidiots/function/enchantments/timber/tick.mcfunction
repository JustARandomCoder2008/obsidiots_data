execute as @a at @s if items entity @s weapon.mainhand *[enchantments~[{enchantments:"obsidiots:timber"}]] if score @s timber_mined_oak matches 1.. run function obsidiots:enchantments/timber/start
execute as @a at @s if items entity @s weapon.mainhand *[enchantments~[{enchantments:"obsidiots:timber"}]] if score @s timber_mined_spruce matches 1.. run function obsidiots:enchantments/timber/start
execute as @a at @s if items entity @s weapon.mainhand *[enchantments~[{enchantments:"obsidiots:timber"}]] if score @s timber_mined_birch matches 1.. run function obsidiots:enchantments/timber/start
execute as @a at @s if items entity @s weapon.mainhand *[enchantments~[{enchantments:"obsidiots:timber"}]] if score @s timber_mined_jungle matches 1.. run function obsidiots:enchantments/timber/start
execute as @a at @s if items entity @s weapon.mainhand *[enchantments~[{enchantments:"obsidiots:timber"}]] if score @s timber_mined_acacia matches 1.. run function obsidiots:enchantments/timber/start
execute as @a at @s if items entity @s weapon.mainhand *[enchantments~[{enchantments:"obsidiots:timber"}]] if score @s timber_mined_dark_oak matches 1.. run function obsidiots:enchantments/timber/start
execute as @a at @s if items entity @s weapon.mainhand *[enchantments~[{enchantments:"obsidiots:timber"}]] if score @s timber_mined_mangrove matches 1.. run function obsidiots:enchantments/timber/start
execute as @a at @s if items entity @s weapon.mainhand *[enchantments~[{enchantments:"obsidiots:timber"}]] if score @s timber_mined_cherry matches 1.. run function obsidiots:enchantments/timber/start
execute as @a at @s if items entity @s weapon.mainhand *[enchantments~[{enchantments:"obsidiots:timber"}]] if score @s timber_mined_pale_oak matches 1.. run function obsidiots:enchantments/timber/start
execute as @a at @s if items entity @s weapon.mainhand *[enchantments~[{enchantments:"obsidiots:timber"}]] if score @s timber_mined_crimson matches 1.. run function obsidiots:enchantments/timber/start
execute as @a at @s if items entity @s weapon.mainhand *[enchantments~[{enchantments:"obsidiots:timber"}]] if score @s timber_mined_warped matches 1.. run function obsidiots:enchantments/timber/start

execute as @a if score @s timber_mined_oak matches 1.. run scoreboard players set @s timber_mined_oak 0
execute as @a if score @s timber_mined_spruce matches 1.. run scoreboard players set @s timber_mined_spruce 0
execute as @a if score @s timber_mined_birch matches 1.. run scoreboard players set @s timber_mined_birch 0
execute as @a if score @s timber_mined_jungle matches 1.. run scoreboard players set @s timber_mined_jungle 0
execute as @a if score @s timber_mined_acacia matches 1.. run scoreboard players set @s timber_mined_acacia 0
execute as @a if score @s timber_mined_dark_oak matches 1.. run scoreboard players set @s timber_mined_dark_oak 0
execute as @a if score @s timber_mined_mangrove matches 1.. run scoreboard players set @s timber_mined_mangrove 0
execute as @a if score @s timber_mined_cherry matches 1.. run scoreboard players set @s timber_mined_cherry 0
execute as @a if score @s timber_mined_pale_oak matches 1.. run scoreboard players set @s timber_mined_pale_oak 0
execute as @a if score @s timber_mined_crimson matches 1.. run scoreboard players set @s timber_mined_crimson 0
execute as @a if score @s timber_mined_warped matches 1.. run scoreboard players set @s timber_mined_warped 0

execute as @e[type=marker,tag=obsidiots_timber] at @s unless entity @p[distance=..5] run kill @s