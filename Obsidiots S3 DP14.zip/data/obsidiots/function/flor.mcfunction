schedule function obsidiots:flor 10t replace

execute as @e[type=cat,nbt={CustomName:"Flor"}] run data merge entity @s {variant: "obsidiots:flor"}
execute as @e[type=cat,nbt={CustomName:"flor"}] run data merge entity @s {variant: "obsidiots:flor"}