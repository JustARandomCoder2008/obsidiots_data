summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:writable_book",count:1}}
data modify entity @e[type=minecraft:item,distance=..1,limit=1,sort=nearest] Item.components."minecraft:writable_book_content".pages set from entity @s SelectedItem.components."minecraft:written_book_content".pages
item replace entity @s weapon.mainhand with minecraft:air
