give @s chest[container_loot={loot_table:"obsidiots:drop_blood"}]
